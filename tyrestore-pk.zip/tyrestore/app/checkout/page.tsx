'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/components/CartProvider';
import { createClient } from '@/lib/supabase/client';

type PaymentMethod = { method_key: string; label: string; instructions: string | null };

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const router = useRouter();
  const supabase = createClient();

  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [form, setForm] = useState({ name: '', phone: '', address: '', city: '', payment: 'cod' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    supabase
      .from('payment_methods')
      .select('method_key, label, instructions')
      .eq('is_enabled', true)
      .then(({ data }) => {
        if (data) {
          setMethods(data);
          if (data[0]) setForm((f) => ({ ...f, payment: data[0].method_key }));
        }
      });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    setSubmitting(true);
    setError('');

    try {
      const { data: userData } = await supabase.auth.getUser();

      const { data: order, error: orderErr } = await supabase
        .from('orders')
        .insert({
          user_id: userData.user?.id || null,
          customer_name: form.name,
          phone: form.phone,
          address: form.address,
          city: form.city,
          payment_method: form.payment,
          total,
          status: 'pending',
        })
        .select()
        .single();

      if (orderErr || !order) throw orderErr;

      const orderItems = items.map((i) => ({
        order_id: order.id,
        tyre_id: i.tyreId,
        tyre_title: i.title,
        quantity: i.quantity,
        price: i.price,
      }));

      const { error: itemsErr } = await supabase.from('order_items').insert(orderItems);
      if (itemsErr) throw itemsErr;

      clearCart();
      router.push(`/checkout/success?order=${order.id}`);
    } catch (err: any) {
      setError('Something went wrong placing your order. Please try again or WhatsApp us.');
    } finally {
      setSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="container-xl py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Your Cart Is Empty</h1>
        <p className="text-tyre-black/60 normal-case">Add tyres to your cart before checking out.</p>
      </div>
    );
  }

  return (
    <div className="container-xl py-12">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>
      <div className="grid lg:grid-cols-3 gap-10">
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-5">
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">Full Name</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
            />
          </div>
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">Phone Number</label>
            <input
              required
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
              placeholder="03XXXXXXXXX"
            />
          </div>
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">Delivery Address</label>
            <textarea
              required
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
              rows={3}
            />
          </div>
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">City</label>
            <input
              required
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
            />
          </div>

          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-2">Payment Method</label>
            <div className="space-y-3">
              {methods.map((m) => (
                <label
                  key={m.method_key}
                  className={`flex flex-col gap-1 border p-4 cursor-pointer ${
                    form.payment === m.method_key ? 'border-tyre-red' : 'border-tyre-line'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="payment"
                      checked={form.payment === m.method_key}
                      onChange={() => setForm({ ...form, payment: m.method_key })}
                    />
                    <span className="font-display">{m.label}</span>
                  </span>
                  {form.payment === m.method_key && m.instructions && (
                    <span className="text-sm text-tyre-black/60 normal-case pl-6">{m.instructions}</span>
                  )}
                </label>
              ))}
            </div>
          </div>

          {error && <p className="text-tyre-red text-sm">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full sm:w-auto">
            {submitting ? 'Placing Order...' : 'Place Order'}
          </button>
        </form>

        <div className="border border-tyre-line p-6 h-fit">
          <h2 className="font-display text-lg mb-4">Order Summary</h2>
          {items.map((i) => (
            <div key={i.tyreId} className="flex justify-between text-sm mb-2">
              <span className="normal-case">{i.title} × {i.quantity}</span>
              <span>Rs. {(i.price * i.quantity).toLocaleString()}</span>
            </div>
          ))}
          <div className="flex justify-between font-display text-lg border-t border-tyre-line pt-4 mt-4">
            <span>Total</span>
            <span>Rs. {total.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
