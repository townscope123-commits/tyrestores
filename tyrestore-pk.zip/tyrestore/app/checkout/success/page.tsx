import Link from 'next/link';

export default function CheckoutSuccessPage({ searchParams }: { searchParams: { order?: string } }) {
  return (
    <div className="container-xl py-24 text-center">
      <div className="w-16 h-16 rounded-full bg-tyre-red text-white flex items-center justify-center mx-auto mb-6 font-display text-2xl">
        ✓
      </div>
      <h1 className="text-3xl font-bold mb-4">Order Placed Successfully!</h1>
      <p className="text-tyre-black/60 max-w-md mx-auto normal-case">
        Thank you for shopping with Tyrestore.pk. Our team will call you shortly to confirm your order.
        {searchParams.order && <> Your order ID is <span className="font-display text-tyre-black">{searchParams.order.slice(0, 8).toUpperCase()}</span>.</>}
      </p>
      <Link href="/tyres" className="btn-primary mt-8 inline-flex">Continue Shopping</Link>
    </div>
  );
}
