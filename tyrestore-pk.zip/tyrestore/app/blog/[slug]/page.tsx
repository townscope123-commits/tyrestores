import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

async function getPost(slug: string) {
  const supabase = createClient();
  const { data } = await supabase.from('blog_posts').select('*').eq('slug', slug).eq('is_published', true).single();
  return data;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = await getPost(params.slug);
  if (!post) return { title: 'Post Not Found' };
  return {
    title: post.meta_title || post.title,
    description: post.meta_description || post.excerpt || '',
    openGraph: {
      title: post.title,
      description: post.excerpt || '',
      images: post.cover_image_url ? [post.cover_image_url] : [],
      type: 'article',
    },
  };
}

export const revalidate = 60;

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await getPost(params.slug);
  if (!post) notFound();

  return (
    <article className="container-xl py-12 max-w-3xl mx-auto">
      <p className="text-xs text-tyre-black/50 normal-case">
        {new Date(post.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'long', year: 'numeric' })}
      </p>
      <h1 className="text-3xl sm:text-4xl font-bold mt-2 mb-8">{post.title}</h1>
      {post.cover_image_url && (
        <div
          className="aspect-video bg-tyre-fog bg-cover bg-center mb-10"
          style={{ backgroundImage: `url(${post.cover_image_url})` }}
        />
      )}
      <div className="prose prose-neutral max-w-none normal-case" dangerouslySetInnerHTML={{ __html: post.content_html || '' }} />
    </article>
  );
}
