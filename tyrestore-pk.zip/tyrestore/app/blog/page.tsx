import type { Metadata } from 'next';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

export const metadata: Metadata = {
  title: 'Blog — Tyre Care Tips & Guides',
  description: 'Tips on tyre maintenance, choosing the right size, seasonal advice and more from the Tyrestore.pk team.',
};

export const revalidate = 60;

export default async function BlogPage() {
  const supabase = createClient();
  const { data: posts } = await supabase
    .from('blog_posts')
    .select('*')
    .eq('is_published', true)
    .order('created_at', { ascending: false });

  return (
    <div className="container-xl py-12">
      <h1 className="text-3xl sm:text-4xl font-bold mb-2">Tyrestore Blog</h1>
      <p className="text-tyre-black/60 mb-10 normal-case">Tyre care tips, buying guides, and the latest from the road.</p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {(posts || []).map((p) => (
          <Link key={p.id} href={`/blog/${p.slug}`} className="group block border border-tyre-line">
            <div
              className="aspect-video bg-tyre-fog bg-cover bg-center"
              style={p.cover_image_url ? { backgroundImage: `url(${p.cover_image_url})` } : {}}
            />
            <div className="p-5">
              <p className="text-xs text-tyre-black/50 normal-case">
                {new Date(p.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
              <h2 className="font-display text-lg mt-2 group-hover:text-tyre-red transition-colors line-clamp-2">{p.title}</h2>
              <p className="text-sm text-tyre-black/60 mt-2 line-clamp-3 normal-case">{p.excerpt}</p>
            </div>
          </Link>
        ))}
        {(!posts || posts.length === 0) && (
          <p className="col-span-full text-center text-tyre-black/50 py-20 normal-case">
            No blog posts yet — add one from the admin panel.
          </p>
        )}
      </div>
    </div>
  );
}
