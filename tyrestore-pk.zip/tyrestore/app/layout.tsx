import type { Metadata } from 'next';
import { Oswald, Inter } from 'next/font/google';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { CartProvider } from '@/components/CartProvider';

const oswald = Oswald({ subsets: ['latin'], variable: '--font-oswald', weight: ['400', '500', '600', '700'] });
const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tyrestore.pk';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'Tyrestore.pk — Buy Car & Bike Tyres Online in Pakistan',
    template: '%s | Tyrestore.pk',
  },
  description:
    'Tyrestore.pk is Pakistan\'s online tyre store — shop genuine car, SUV and bike tyres from top brands with fast advance shipping and Cash on Delivery across Pakistan.',
  keywords: [
    'tyres Pakistan', 'car tyres online', 'buy tyres Pakistan', 'bike tyres', 'Tyrestore.pk',
    'tyre shop Multan', 'tyre price Pakistan', 'imported tyres Pakistan',
  ],
  openGraph: {
    title: 'Tyrestore.pk — Buy Car & Bike Tyres Online in Pakistan',
    description: 'Shop genuine tyres online with fast shipping and Cash on Delivery across Pakistan.',
    url: SITE_URL,
    siteName: 'Tyrestore.pk',
    locale: 'en_PK',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tyrestore.pk — Buy Car & Bike Tyres Online in Pakistan',
    description: 'Shop genuine tyres online with fast shipping and Cash on Delivery across Pakistan.',
  },
  robots: { index: true, follow: true },
  icons: {
    icon: '/icon',
    shortcut: '/icon',
    apple: '/icon',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${oswald.variable} ${inter.variable}`}>
      <body>
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
        </CartProvider>
      </body>
    </html>
  );
}
