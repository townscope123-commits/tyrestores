import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Terms & Conditions',
  description: 'Read the terms and conditions for shopping on Tyrestore.pk, including orders, payments, shipping and returns.',
};

export default function TermsPage() {
  return (
    <div className="container-xl py-16 max-w-3xl mx-auto">
      <h1 className="text-3xl sm:text-4xl font-bold mb-8">Terms &amp; Conditions</h1>
      <div className="prose prose-neutral max-w-none normal-case space-y-6 text-tyre-black/80 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold mb-2">1. General</h2>
          <p>By using Tyrestore.pk, you agree to these terms. We reserve the right to update this page at any time without prior notice.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold mb-2">2. Orders &amp; Payment</h2>
          <p>Orders can be placed through the website and paid for via Cash on Delivery or Bank Transfer, as selected at checkout. Orders are confirmed by our team via phone call before dispatch.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold mb-2">3. Shipping</h2>
          <p>We offer advance shipping across Pakistan. Delivery times vary by city and are estimated at checkout. Tyrestore.pk is not responsible for delays caused by courier partners or circumstances beyond our control.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold mb-2">4. Returns &amp; Exchanges</h2>
          <p>Tyres with manufacturing defects can be returned or exchanged within 7 days of delivery. Tyres must be unused and in original condition. Contact our support team via WhatsApp to initiate a return.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold mb-2">5. Pricing</h2>
          <p>Prices are listed in Pakistani Rupees (PKR) and are subject to change without notice. We aim to display accurate pricing at all times but reserve the right to correct any errors.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold mb-2">6. Contact</h2>
          <p>For any questions about these terms, reach out to us at info@tyrestore.pk or via WhatsApp.</p>
        </section>
      </div>
    </div>
  );
}
