import { ImageResponse } from 'next/og';

export const size = { width: 64, height: 64 };
export const contentType = 'image/png';

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          background: '#0A0A0A',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 12,
        }}
      >
        <div style={{ display: 'flex', fontSize: 30, fontWeight: 700, color: '#fff', fontFamily: 'sans-serif' }}>
          T<span style={{ color: '#D91E2B' }}>S</span>
        </div>
      </div>
    ),
    { ...size }
  );
}
