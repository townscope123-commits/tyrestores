import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import TyreCard from '@/components/TyreCard';

export const revalidate = 60;

export default async function HomePage() {
  const supabase = createClient();

  const [{ data: featured }, { data: latest }, { data: posts }] = await Promise.all([
    supabase.from('tyres').select('*').eq('is_featured', true).limit(8),
    supabase.from('tyres').select('*').order('created_at', { ascending: false }).limit(8),
    supabase.from('blog_posts').select('*').eq('is_published', true).order('created_at', { ascending: false }).limit(3),
  ]);

  const featuredTyres = featured && featured.length > 0 ? featured : latest || [];

  return (
    <div>
      {/* HERO — signature tread-pattern texture on black */}
      <section className="relative bg-tyre-black text-white overflow-hidden">
        <div className="absolute inset-0 bg-tread opacity-40" />
        <div className="container-xl relative py-20 sm:py-28 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <span className="inline-block bg-tyre-red text-white text-xs font-display uppercase tracking-widest px-3 py-1 mb-5">
              Pakistan's Online Tyre Store
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
              Grip The Road.<br />
              <span className="text-tyre-red">Own The Ride.</span>
            </h1>
            <p className="mt-6 text-white/70 text-base sm:text-lg max-w-lg font-body normal-case">
              Genuine car, SUV and bike tyres from trusted brands — delivered to your door
              anywhere in Pakistan, with fast advance shipping and Cash on Delivery.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/tyres" className="btn-primary">Shop Tyres</Link>
              <Link href="/contact" className="btn-outline !border-white !text-white hover:!bg-white hover:!text-tyre-black">
                Talk To An Expert
              </Link>
            </div>

            {/* speedometer-style stat blocks */}
            <div className="mt-12 grid grid-cols-3 gap-6 max-w-md">
              <div>
                <p className="font-display text-3xl text-tyre-red">5000+</p>
                <p className="text-xs text-white/50 uppercase tracking-wide mt-1">Tyres Delivered</p>
              </div>
              <div>
                <p className="font-display text-3xl text-tyre-red">30+</p>
                <p className="text-xs text-white/50 uppercase tracking-wide mt-1">Cities Covered</p>
              </div>
              <div>
                <p className="font-display text-3xl text-tyre-red">100%</p>
                <p className="text-xs text-white/50 uppercase tracking-wide mt-1">Genuine Stock</p>
              </div>
            </div>
          </div>

          {/* Tyre-tread ring graphic */}
          <div className="hidden lg:flex items-center justify-center">
            <div className="relative w-80 h-80 rounded-full border-[18px] border-tyre-red/20">
              <div className="absolute inset-4 rounded-full border-[14px] border-white/10" />
              <div className="absolute inset-10 rounded-full bg-tyre-red/10 flex items-center justify-center">
                <span className="font-display text-2xl text-white/80 text-center leading-tight">
                  Fit Right.<br />Drive Safe.
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="tread-divider" />

      {/* SHOP BY SEASON */}
      <section className="container-xl py-16">
        <h2 className="text-2xl sm:text-3xl font-bold mb-2">Shop By Category</h2>
        <p className="text-tyre-black/60 mb-8 normal-case">Find the right tyre for every road and every season.</p>
        <div className="grid sm:grid-cols-3 gap-6">
          {[
            { label: 'Summer Tyres', href: '/tyres?season=Summer', desc: 'Superior grip and handling on dry, hot roads.' },
            { label: 'All Season Tyres', href: '/tyres?season=All+Season', desc: 'Reliable performance in every condition, year round.' },
            { label: 'Bike Tyres', href: '/tyres?type=bike', desc: 'Durable, high-traction tyres for daily commuting.' },
          ].map((c) => (
            <Link
              key={c.label}
              href={c.href}
              className="group border border-tyre-line p-6 hover:border-tyre-red transition-colors"
            >
              <h3 className="font-display text-xl group-hover:text-tyre-red transition-colors">{c.label}</h3>
              <p className="text-sm text-tyre-black/60 mt-2 normal-case">{c.desc}</p>
              <span className="inline-block mt-4 text-xs font-display uppercase tracking-wide text-tyre-red">Browse →</span>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED TYRES */}
      <section className="bg-tyre-fog py-16">
        <div className="container-xl">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold mb-2">Featured Tyres</h2>
              <p className="text-tyre-black/60 normal-case">Handpicked, best-selling tyres this month.</p>
            </div>
            <Link href="/tyres" className="hidden sm:inline text-sm font-display uppercase tracking-wide text-tyre-red">
              View All →
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {featuredTyres.map((t) => (
              <TyreCard key={t.id} tyre={t} />
            ))}
            {featuredTyres.length === 0 && (
              <p className="col-span-full text-center text-tyre-black/50 py-12 normal-case">
                Tyres will appear here once added from the admin panel.
              </p>
            )}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="container-xl py-16">
        <h2 className="text-2xl sm:text-3xl font-bold mb-10 text-center">Why Choose Tyrestore.pk?</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: 'Advance Shipping', desc: 'Fast, tracked delivery to all major cities across Pakistan.' },
            { title: 'Cash On Delivery', desc: 'Pay when your tyres arrive — no advance payment required.' },
            { title: '100% Genuine', desc: 'Every tyre is sourced directly from authorized brand dealers.' },
            { title: 'Expert Support', desc: 'Not sure which size fits? Message us on WhatsApp anytime.' },
          ].map((f) => (
            <div key={f.title} className="text-center">
              <div className="w-14 h-14 mx-auto rounded-full bg-tyre-black flex items-center justify-center mb-4">
                <div className="w-6 h-6 rounded-full border-2 border-tyre-red" />
              </div>
              <h3 className="font-display text-lg mb-2">{f.title}</h3>
              <p className="text-sm text-tyre-black/60 normal-case">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* BLOG PREVIEW */}
      {posts && posts.length > 0 && (
        <section className="bg-tyre-fog py-16">
          <div className="container-xl">
            <div className="flex items-end justify-between mb-8">
              <h2 className="text-2xl sm:text-3xl font-bold">From The Blog</h2>
              <Link href="/blog" className="text-sm font-display uppercase tracking-wide text-tyre-red">View All →</Link>
            </div>
            <div className="grid sm:grid-cols-3 gap-6">
              {posts.map((p) => (
                <Link key={p.id} href={`/blog/${p.slug}`} className="group block border border-tyre-line">
                  <div className="aspect-video bg-tyre-black/5" />
                  <div className="p-5">
                    <h3 className="font-display text-lg group-hover:text-tyre-red transition-colors line-clamp-2">{p.title}</h3>
                    <p className="text-sm text-tyre-black/60 mt-2 line-clamp-2 normal-case">{p.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="bg-tyre-black text-white py-16 text-center">
        <div className="container-xl">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">Need Help Picking The Right Size?</h2>
          <p className="text-white/60 mb-8 max-w-xl mx-auto normal-case">
            Message our team on WhatsApp with your vehicle details and we'll recommend the best tyre for your budget.
          </p>
          <Link href="/contact" className="btn-primary">Get In Touch</Link>
        </div>
      </section>
    </div>
  );
}
