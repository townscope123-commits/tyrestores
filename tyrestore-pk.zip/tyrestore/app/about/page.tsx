import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn about Tyrestore.pk — Pakistan\'s trusted online tyre store bringing genuine car, SUV and bike tyres to your doorstep.',
};

export default function AboutPage() {
  return (
    <div className="container-xl py-16 max-w-3xl mx-auto">
      <h1 className="text-3xl sm:text-4xl font-bold mb-6">About Tyrestore.pk</h1>
      <div className="prose prose-neutral max-w-none normal-case space-y-4 text-tyre-black/80 leading-relaxed">
        <p>
          Tyrestore.pk was built with one simple goal: make buying tyres in Pakistan as easy as ordering
          anything else online. No more visiting shop after shop comparing prices — we bring genuine,
          quality-checked tyres from trusted brands straight to your doorstep, anywhere in the country.
        </p>
        <p>
          From daily-use sedans to rugged SUVs and everyday bikes, our catalogue covers a wide range of
          sizes and patterns to match your vehicle and your budget. Every tyre listed on our platform is
          sourced directly from authorized dealers, so you can shop with confidence.
        </p>
        <p>
          We know that ordering a tyre online can feel different from ordering it in person — that's why
          our team is always a WhatsApp message away to help you pick the right size, confirm fitment, and
          answer any questions before you buy.
        </p>
        <h2 className="text-2xl font-bold pt-6">Our Promise</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>100% genuine tyres, sourced from authorized dealers</li>
          <li>Fast, advance shipping across Pakistan</li>
          <li>Cash on Delivery available on all orders</li>
          <li>Friendly, knowledgeable support before and after your purchase</li>
        </ul>
      </div>
    </div>
  );
}
