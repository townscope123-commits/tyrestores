'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function RegisterPage() {
  const supabase = createClient();
  const router = useRouter();
  const [form, setForm] = useState({ full_name: '', phone: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { error: signUpError } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: { data: { full_name: form.full_name, phone: form.phone } },
    });
    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }
    router.push('/login');
  };

  return (
    <div className="container-xl py-20 max-w-md mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Create Account</h1>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Full Name</label>
          <input
            required
            value={form.full_name}
            onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Phone</label>
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Email</label>
          <input
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Password</label>
          <input
            type="password"
            required
            minLength={6}
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        {error && <p className="text-tyre-red text-sm">{error}</p>}
        <button disabled={loading} type="submit" className="btn-primary w-full">
          {loading ? 'Creating Account...' : 'Sign Up'}
        </button>
      </form>
      <p className="text-sm text-center mt-6 normal-case">
        Already have an account? <Link href="/login" className="text-tyre-red">Login</Link>
      </p>
    </div>
  );
}
