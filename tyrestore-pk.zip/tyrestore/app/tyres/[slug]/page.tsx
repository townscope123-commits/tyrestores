import type { Metadata } from 'next';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AddToCartButton from '@/components/AddToCartButton';
import TyreCard from '@/components/TyreCard';

async function getTyre(slug: string) {
  const supabase = createClient();
  const { data } = await supabase.from('tyres').select('*').eq('slug', slug).single();
  return data;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const tyre = await getTyre(params.slug);
  if (!tyre) return { title: 'Tyre Not Found' };
  return {
    title: tyre.meta_title || `${tyre.title} — Buy Online`,
    description: tyre.meta_description || tyre.short_description || `Buy ${tyre.title} online in Pakistan with fast delivery and Cash on Delivery.`,
    openGraph: {
      title: tyre.title,
      description: tyre.short_description || '',
      images: tyre.image_url ? [tyre.image_url] : [],
    },
  };
}

export const revalidate = 60;

export default async function TyreDetailPage({ params }: { params: { slug: string } }) {
  const tyre = await getTyre(params.slug);
  if (!tyre) notFound();

  const supabase = createClient();
  const { data: related } = await supabase
    .from('tyres')
    .select('*')
    .neq('id', tyre.id)
    .eq('season', tyre.season)
    .limit(4);

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: tyre.title,
    image: tyre.image_url ? [tyre.image_url] : [],
    description: tyre.short_description,
    offers: {
      '@type': 'Offer',
      priceCurrency: 'PKR',
      price: tyre.discount_price || tyre.price,
      availability: tyre.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
    },
  };

  return (
    <div className="container-xl py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="aspect-square bg-tyre-fog relative">
          {tyre.image_url ? (
            <Image src={tyre.image_url} alt={tyre.title} fill className="object-contain p-10" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-tyre-black/20 font-display text-6xl">TS</div>
          )}
        </div>

        <div>
          <p className="text-xs uppercase tracking-wide text-tyre-red font-display">{tyre.season || 'All Season'}</p>
          <h1 className="text-3xl sm:text-4xl font-bold mt-2">{tyre.title}</h1>
          <p className="text-tyre-black/60 mt-2 normal-case">Size: {tyre.size || 'N/A'} {tyre.pattern ? `· Pattern: ${tyre.pattern}` : ''}</p>

          <div className="mt-6 flex items-center gap-3">
            {tyre.discount_price && tyre.discount_price < tyre.price ? (
              <>
                <span className="font-display text-3xl text-tyre-red">Rs. {tyre.discount_price.toLocaleString()}</span>
                <span className="text-lg text-tyre-black/40 line-through">Rs. {tyre.price.toLocaleString()}</span>
              </>
            ) : (
              <span className="font-display text-3xl">Rs. {tyre.price.toLocaleString()}</span>
            )}
          </div>

          <p className={`mt-2 text-sm font-display uppercase tracking-wide ${tyre.stock > 0 ? 'text-green-600' : 'text-tyre-red'}`}>
            {tyre.stock > 0 ? 'In Stock' : 'Out Of Stock'}
          </p>

          {tyre.short_description && (
            <p className="mt-4 text-tyre-black/70 normal-case leading-relaxed">{tyre.short_description}</p>
          )}

          <div className="mt-8">
            <AddToCartButton
              tyreId={tyre.id}
              title={tyre.title}
              price={tyre.discount_price || tyre.price}
              image_url={tyre.image_url}
            />
          </div>

          <div className="mt-8 border-t border-tyre-line pt-6 text-sm text-tyre-black/60 normal-case space-y-1">
            <p>🚚 Advance shipping across Pakistan</p>
            <p>💵 Cash on Delivery available</p>
            <p>📞 Need help? WhatsApp us for expert advice</p>
          </div>
        </div>
      </div>

      {/* Rich text tyre description — dedicated content block, entered via admin editor */}
      {tyre.description_html && (
        <div className="mt-16 max-w-3xl">
          <h2 className="text-2xl font-bold mb-4">Product Details</h2>
          <div
            className="prose prose-neutral max-w-none normal-case"
            dangerouslySetInnerHTML={{ __html: tyre.description_html }}
          />
        </div>
      )}

      {related && related.length > 0 && (
        <div className="mt-20">
          <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            {related.map((t) => (
              <TyreCard key={t.id} tyre={t} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
