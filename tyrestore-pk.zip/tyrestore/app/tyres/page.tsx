import type { Metadata } from 'next';
import { createClient } from '@/lib/supabase/server';
import TyreCard from '@/components/TyreCard';

export const metadata: Metadata = {
  title: 'Shop All Tyres',
  description: 'Browse our full range of car, SUV and bike tyres. Filter by season and size. Fast shipping and Cash on Delivery across Pakistan.',
};

export const revalidate = 60;

export default async function TyresPage({
  searchParams,
}: {
  searchParams: { season?: string; featured?: string };
}) {
  const supabase = createClient();
  let query = supabase.from('tyres').select('*').order('created_at', { ascending: false });

  if (searchParams.season) query = query.eq('season', searchParams.season);
  if (searchParams.featured) query = query.eq('is_featured', true);

  const { data: tyres } = await query;

  return (
    <div className="container-xl py-12">
      <div className="mb-10">
        <h1 className="text-3xl sm:text-4xl font-bold">Shop All Tyres</h1>
        <p className="text-tyre-black/60 mt-2 normal-case">
          {tyres?.length || 0} tyres available — genuine stock, fast advance shipping, Cash on Delivery.
        </p>
      </div>

      <div className="flex flex-wrap gap-3 mb-8">
        {['Summer', 'Winter', 'All Season'].map((s) => (
          <a
            key={s}
            href={`/tyres?season=${encodeURIComponent(s)}`}
            className={`text-xs font-display uppercase tracking-wide px-4 py-2 border ${
              searchParams.season === s ? 'bg-tyre-red text-white border-tyre-red' : 'border-tyre-line hover:border-tyre-red'
            }`}
          >
            {s}
          </a>
        ))}
        <a
          href="/tyres"
          className={`text-xs font-display uppercase tracking-wide px-4 py-2 border ${
            !searchParams.season ? 'bg-tyre-black text-white border-tyre-black' : 'border-tyre-line hover:border-tyre-black'
          }`}
        >
          All
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
        {(tyres || []).map((t) => (
          <TyreCard key={t.id} tyre={t} />
        ))}
        {(!tyres || tyres.length === 0) && (
          <p className="col-span-full text-center text-tyre-black/50 py-20 normal-case">
            No tyres found. Add tyres from the admin panel to see them here.
          </p>
        )}
      </div>
    </div>
  );
}
