'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function AdminLoginPage() {
  const supabase = createClient();
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { data, error: signInError } = await supabase.auth.signInWithPassword(form);
    if (signInError || !data.user) {
      setError('Invalid email or password.');
      setLoading(false);
      return;
    }

    const { data: profile } = await supabase.from('profiles').select('is_admin').eq('id', data.user.id).single();
    if (!profile?.is_admin) {
      setError('This account does not have admin access.');
      await supabase.auth.signOut();
      setLoading(false);
      return;
    }

    await supabase.from('login_logs').insert({
      user_id: data.user.id,
      email: data.user.email,
      user_agent: navigator.userAgent,
    });

    router.push('/admin');
    router.refresh();
  };

  return (
    <div className="min-h-screen bg-tyre-black flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white p-8">
        <div className="text-center mb-8">
          <span className="font-display text-2xl font-bold">
            TYRE<span className="text-tyre-red">STORE</span>
          </span>
          <p className="text-xs uppercase tracking-widest text-tyre-black/50 mt-1">Admin Panel</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">Email</label>
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
            />
          </div>
          <div>
            <label className="block text-sm font-display uppercase tracking-wide mb-1">Password</label>
            <input
              type="password"
              required
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              className="w-full border border-tyre-line px-4 py-3"
            />
          </div>
          {error && <p className="text-tyre-red text-sm">{error}</p>}
          <button disabled={loading} type="submit" className="btn-primary w-full">
            {loading ? 'Logging In...' : 'Login To Admin'}
          </button>
        </form>
      </div>
    </div>
  );
}
