'use client';

import { usePathname } from 'next/navigation';
import AdminSidebar from '@/components/AdminSidebar';

export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isLoginPage = pathname === '/admin/login';

  if (isLoginPage) return <>{children}</>;

  return (
    <div className="flex flex-col sm:flex-row">
      <AdminSidebar />
      <div className="flex-1 bg-tyre-fog min-h-screen p-6 sm:p-10">{children}</div>
    </div>
  );
}
