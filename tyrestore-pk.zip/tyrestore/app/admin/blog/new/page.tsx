import BlogForm from '@/components/BlogForm';

export default function NewBlogPostPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Add New Blog Post</h1>
      <BlogForm />
    </div>
  );
}
