import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import DeleteButton from '@/components/DeleteButton';

export default async function AdminBlogPage() {
  const supabase = createClient();
  const { data: posts } = await supabase.from('blog_posts').select('*').order('created_at', { ascending: false });

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Blog Posts</h1>
        <Link href="/admin/blog/new" className="btn-primary !py-2">+ Add New Post</Link>
      </div>

      <div className="bg-white border border-tyre-line overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-tyre-black text-white">
            <tr>
              <th className="text-left px-4 py-3">Title</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="text-left px-4 py-3">Date</th>
              <th className="text-right px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(posts || []).map((p) => (
              <tr key={p.id} className="border-t border-tyre-line">
                <td className="px-4 py-3">{p.title}</td>
                <td className="px-4 py-3">{p.is_published ? 'Published' : 'Draft'}</td>
                <td className="px-4 py-3">{new Date(p.created_at).toLocaleDateString('en-PK')}</td>
                <td className="px-4 py-3 text-right space-x-3">
                  <Link href={`/admin/blog/${p.id}/edit`} className="text-tyre-red font-display text-xs uppercase">Edit</Link>
                  <DeleteButton table="blog_posts" id={p.id} />
                </td>
              </tr>
            ))}
            {(!posts || posts.length === 0) && (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-tyre-black/50">No posts yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
