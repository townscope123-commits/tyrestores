import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import BlogForm from '@/components/BlogForm';

export default async function EditBlogPostPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: post } = await supabase.from('blog_posts').select('*').eq('id', params.id).single();
  if (!post) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Edit Blog Post</h1>
      <BlogForm initial={post} />
    </div>
  );
}
