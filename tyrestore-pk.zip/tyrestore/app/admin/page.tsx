import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

export default async function AdminDashboard() {
  const supabase = createClient();

  const [{ count: tyreCount }, { count: orderCount }, { count: pendingCount }, { count: userCount }, { data: recentOrders }] =
    await Promise.all([
      supabase.from('tyres').select('*', { count: 'exact', head: true }),
      supabase.from('orders').select('*', { count: 'exact', head: true }),
      supabase.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(5),
    ]);

  const stats = [
    { label: 'Total Tyres', value: tyreCount || 0, href: '/admin/tyres' },
    { label: 'Total Orders', value: orderCount || 0, href: '/admin/orders' },
    { label: 'Pending Orders', value: pendingCount || 0, href: '/admin/orders' },
    { label: 'Registered Users', value: userCount || 0, href: '/admin/users' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Dashboard</h1>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        {stats.map((s) => (
          <Link key={s.label} href={s.href} className="bg-white border border-tyre-line p-6 hover:border-tyre-red transition-colors">
            <p className="font-display text-3xl">{s.value}</p>
            <p className="text-xs uppercase tracking-wide text-tyre-black/50 mt-2">{s.label}</p>
          </Link>
        ))}
      </div>

      <div className="bg-white border border-tyre-line p-6">
        <h2 className="font-display text-lg mb-4">Recent Orders</h2>
        <div className="space-y-3">
          {(recentOrders || []).map((o) => (
            <Link key={o.id} href={`/admin/orders/${o.id}`} className="flex justify-between items-center border-b border-tyre-line pb-3 last:border-0 hover:text-tyre-red">
              <span className="text-sm">#{o.id.slice(0, 8).toUpperCase()} — {o.customer_name}</span>
              <span className="text-xs uppercase font-display px-2 py-1 bg-tyre-fog">{o.status}</span>
              <span className="text-sm font-display">Rs. {o.total.toLocaleString()}</span>
            </Link>
          ))}
          {(!recentOrders || recentOrders.length === 0) && <p className="text-sm text-tyre-black/50">No orders yet.</p>}
        </div>
      </div>
    </div>
  );
}
