import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import OrderStatusUpdater from '@/components/OrderStatusUpdater';

export default async function AdminOrderDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: order } = await supabase.from('orders').select('*, order_items(*)').eq('id', params.id).single();
  if (!order) notFound();

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-8">Order #{order.id.slice(0, 8).toUpperCase()}</h1>

      <div className="bg-white border border-tyre-line p-6 mb-6">
        <h2 className="font-display text-lg mb-4">Customer Details</h2>
        <div className="grid sm:grid-cols-2 gap-4 text-sm">
          <p><span className="text-tyre-black/50 block text-xs uppercase">Name</span>{order.customer_name}</p>
          <p><span className="text-tyre-black/50 block text-xs uppercase">Phone</span>{order.phone}</p>
          <p><span className="text-tyre-black/50 block text-xs uppercase">City</span>{order.city}</p>
          <p><span className="text-tyre-black/50 block text-xs uppercase">Payment Method</span>{order.payment_method.toUpperCase()}</p>
          <p className="sm:col-span-2"><span className="text-tyre-black/50 block text-xs uppercase">Address</span>{order.address}</p>
        </div>
      </div>

      <div className="bg-white border border-tyre-line p-6 mb-6">
        <h2 className="font-display text-lg mb-4">Items</h2>
        <div className="space-y-2 text-sm">
          {order.order_items?.map((item: any) => (
            <div key={item.id} className="flex justify-between border-b border-tyre-line pb-2">
              <span>{item.tyre_title} × {item.quantity}</span>
              <span>Rs. {(item.price * item.quantity).toLocaleString()}</span>
            </div>
          ))}
        </div>
        <div className="flex justify-between font-display text-lg pt-4">
          <span>Total</span>
          <span>Rs. {order.total.toLocaleString()}</span>
        </div>
      </div>

      <div className="bg-white border border-tyre-line p-6">
        <h2 className="font-display text-lg mb-4">Order Status</h2>
        <OrderStatusUpdater orderId={order.id} currentStatus={order.status} />
      </div>
    </div>
  );
}
