import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  shipped: 'bg-purple-100 text-purple-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
};

export default async function AdminOrdersPage() {
  const supabase = createClient();
  const { data: orders } = await supabase.from('orders').select('*').order('created_at', { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Orders</h1>

      <div className="bg-white border border-tyre-line overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-tyre-black text-white">
            <tr>
              <th className="text-left px-4 py-3">Order ID</th>
              <th className="text-left px-4 py-3">Customer</th>
              <th className="text-left px-4 py-3">Phone</th>
              <th className="text-left px-4 py-3">Payment</th>
              <th className="text-left px-4 py-3">Total</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="text-left px-4 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {(orders || []).map((o) => (
              <tr key={o.id} className="border-t border-tyre-line hover:bg-tyre-fog cursor-pointer">
                <td className="px-4 py-3">
                  <Link href={`/admin/orders/${o.id}`} className="text-tyre-red font-display">
                    #{o.id.slice(0, 8).toUpperCase()}
                  </Link>
                </td>
                <td className="px-4 py-3">{o.customer_name}</td>
                <td className="px-4 py-3">{o.phone}</td>
                <td className="px-4 py-3 uppercase text-xs">{o.payment_method}</td>
                <td className="px-4 py-3">Rs. {o.total.toLocaleString()}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-display uppercase px-2 py-1 rounded-sm ${STATUS_COLORS[o.status] || ''}`}>
                    {o.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-tyre-black/60">
                  {new Date(o.created_at).toLocaleDateString('en-PK')}
                </td>
              </tr>
            ))}
            {(!orders || orders.length === 0) && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-tyre-black/50">No orders yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
