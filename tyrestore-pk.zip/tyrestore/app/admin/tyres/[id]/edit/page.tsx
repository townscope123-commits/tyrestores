import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import TyreForm from '@/components/TyreForm';

export default async function EditTyrePage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: tyre } = await supabase.from('tyres').select('*').eq('id', params.id).single();
  if (!tyre) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Edit Tyre</h1>
      <TyreForm initial={tyre} />
    </div>
  );
}
