import TyreForm from '@/components/TyreForm';

export default function NewTyrePage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Add New Tyre</h1>
      <TyreForm />
    </div>
  );
}
