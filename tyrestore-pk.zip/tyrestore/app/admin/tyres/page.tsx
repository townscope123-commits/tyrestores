import Link from 'next/link';
import Image from 'next/image';
import { createClient } from '@/lib/supabase/server';
import DeleteButton from '@/components/DeleteButton';

export default async function AdminTyresPage() {
  const supabase = createClient();
  const { data: tyres } = await supabase.from('tyres').select('*').order('created_at', { ascending: false });

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Tyres</h1>
        <Link href="/admin/tyres/new" className="btn-primary !py-2">+ Add New Tyre</Link>
      </div>

      <div className="bg-white border border-tyre-line overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-tyre-black text-white">
            <tr>
              <th className="text-left px-4 py-3">Image</th>
              <th className="text-left px-4 py-3">Title</th>
              <th className="text-left px-4 py-3">Size</th>
              <th className="text-left px-4 py-3">Price</th>
              <th className="text-left px-4 py-3">Stock</th>
              <th className="text-left px-4 py-3">Featured</th>
              <th className="text-right px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(tyres || []).map((t) => (
              <tr key={t.id} className="border-t border-tyre-line">
                <td className="px-4 py-3">
                  <div className="relative w-12 h-12 bg-tyre-fog">
                    {t.image_url && <Image src={t.image_url} alt={t.title} fill className="object-contain" />}
                  </div>
                </td>
                <td className="px-4 py-3">{t.title}</td>
                <td className="px-4 py-3">{t.size}</td>
                <td className="px-4 py-3">Rs. {t.price.toLocaleString()}</td>
                <td className="px-4 py-3">{t.stock}</td>
                <td className="px-4 py-3">{t.is_featured ? '✓' : '—'}</td>
                <td className="px-4 py-3 text-right space-x-3">
                  <Link href={`/admin/tyres/${t.id}/edit`} className="text-tyre-red font-display text-xs uppercase">Edit</Link>
                  <DeleteButton table="tyres" id={t.id} />
                </td>
              </tr>
            ))}
            {(!tyres || tyres.length === 0) && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-tyre-black/50">No tyres yet. Add your first one.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
