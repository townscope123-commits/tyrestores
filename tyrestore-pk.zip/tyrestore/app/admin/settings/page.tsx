'use client';

import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

type PaymentMethod = { id: string; method_key: string; label: string; instructions: string; is_enabled: boolean };

export default function AdminSettingsPage() {
  const supabase = createClient();
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    supabase.from('payment_methods').select('*').then(({ data }) => data && setMethods(data));
  }, []);

  const updateMethod = async (id: string, changes: Partial<PaymentMethod>) => {
    setMethods((prev) => prev.map((m) => (m.id === id ? { ...m, ...changes } : m)));
  };

  const saveMethod = async (m: PaymentMethod) => {
    setSaving(m.id);
    await supabase.from('payment_methods').update({
      label: m.label,
      instructions: m.instructions,
      is_enabled: m.is_enabled,
    }).eq('id', m.id);
    setSaving(null);
  };

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-2">Payment Settings</h1>
      <p className="text-sm text-tyre-black/60 mb-8 normal-case">
        Turn payment methods on or off, and edit the instructions customers see at checkout.
      </p>

      <div className="space-y-6">
        {methods.map((m) => (
          <div key={m.id} className="bg-white border border-tyre-line p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg">{m.method_key === 'cod' ? 'Cash On Delivery' : m.label}</h2>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={m.is_enabled}
                  onChange={(e) => updateMethod(m.id, { is_enabled: e.target.checked })}
                />
                Enabled
              </label>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-display uppercase tracking-wide mb-1">Display Label</label>
                <input
                  value={m.label}
                  onChange={(e) => updateMethod(m.id, { label: e.target.value })}
                  className="w-full border border-tyre-line px-4 py-2"
                />
              </div>
              <div>
                <label className="block text-xs font-display uppercase tracking-wide mb-1">
                  Instructions Shown At Checkout {m.method_key === 'bank_transfer' && '(add your bank account details here)'}
                </label>
                <textarea
                  value={m.instructions || ''}
                  onChange={(e) => updateMethod(m.id, { instructions: e.target.value })}
                  rows={3}
                  className="w-full border border-tyre-line px-4 py-2"
                />
              </div>
            </div>
            <button onClick={() => saveMethod(m)} className="btn-primary !py-2 mt-4">
              {saving === m.id ? 'Saving...' : 'Save'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
