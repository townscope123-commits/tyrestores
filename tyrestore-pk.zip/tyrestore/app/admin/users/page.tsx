import { createClient } from '@/lib/supabase/server';

export default async function AdminUsersPage() {
  const supabase = createClient();

  const [{ data: profiles }, { data: logins }] = await Promise.all([
    supabase.from('profiles').select('*').order('created_at', { ascending: false }),
    supabase.from('login_logs').select('*').order('logged_in_at', { ascending: false }).limit(50),
  ]);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-2xl font-bold mb-6">Registered Users</h1>
        <div className="bg-white border border-tyre-line overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-tyre-black text-white">
              <tr>
                <th className="text-left px-4 py-3">Name</th>
                <th className="text-left px-4 py-3">Phone</th>
                <th className="text-left px-4 py-3">Admin</th>
                <th className="text-left px-4 py-3">Joined</th>
              </tr>
            </thead>
            <tbody>
              {(profiles || []).map((p) => (
                <tr key={p.id} className="border-t border-tyre-line">
                  <td className="px-4 py-3">{p.full_name || '—'}</td>
                  <td className="px-4 py-3">{p.phone || '—'}</td>
                  <td className="px-4 py-3">{p.is_admin ? '✓' : '—'}</td>
                  <td className="px-4 py-3 text-xs text-tyre-black/60">{new Date(p.created_at).toLocaleDateString('en-PK')}</td>
                </tr>
              ))}
              {(!profiles || profiles.length === 0) && (
                <tr><td colSpan={4} className="px-4 py-10 text-center text-tyre-black/50">No registered users yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-6">Recent Login Activity</h2>
        <p className="text-sm text-tyre-black/60 mb-4 normal-case">
          See who's logging into the store — every customer and admin login is recorded here.
        </p>
        <div className="bg-white border border-tyre-line overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-tyre-black text-white">
              <tr>
                <th className="text-left px-4 py-3">Email</th>
                <th className="text-left px-4 py-3">Logged In At</th>
                <th className="text-left px-4 py-3">Device</th>
              </tr>
            </thead>
            <tbody>
              {(logins || []).map((l) => (
                <tr key={l.id} className="border-t border-tyre-line">
                  <td className="px-4 py-3">{l.email}</td>
                  <td className="px-4 py-3 text-xs">{new Date(l.logged_in_at).toLocaleString('en-PK')}</td>
                  <td className="px-4 py-3 text-xs text-tyre-black/60 truncate max-w-xs">{l.user_agent}</td>
                </tr>
              ))}
              {(!logins || logins.length === 0) && (
                <tr><td colSpan={3} className="px-4 py-10 text-center text-tyre-black/50">No login activity yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
