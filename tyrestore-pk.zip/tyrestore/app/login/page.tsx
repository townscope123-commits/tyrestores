'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const supabase = createClient();
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { data, error: signInError } = await supabase.auth.signInWithPassword(form);
    if (signInError) {
      setError('Invalid email or password.');
      setLoading(false);
      return;
    }
    // log this login for the admin "who's logging in" view
    if (data.user) {
      await supabase.from('login_logs').insert({
        user_id: data.user.id,
        email: data.user.email,
        user_agent: navigator.userAgent,
      });
    }
    router.push('/account');
    router.refresh();
  };

  return (
    <div className="container-xl py-20 max-w-md mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Login</h1>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Email</label>
          <input
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Password</label>
          <input
            type="password"
            required
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        {error && <p className="text-tyre-red text-sm">{error}</p>}
        <button disabled={loading} type="submit" className="btn-primary w-full">
          {loading ? 'Logging In...' : 'Login'}
        </button>
      </form>
      <p className="text-sm text-center mt-6 normal-case">
        Don't have an account? <Link href="/register" className="text-tyre-red">Sign up</Link>
      </p>
    </div>
  );
}
