import type { MetadataRoute } from 'next';
import { createClient } from '@/lib/supabase/server';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tyrestore.pk';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const supabase = createClient();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE_URL}/`, changeFrequency: 'daily', priority: 1 },
    { url: `${SITE_URL}/tyres`, changeFrequency: 'daily', priority: 0.9 },
    { url: `${SITE_URL}/blog`, changeFrequency: 'daily', priority: 0.7 },
    { url: `${SITE_URL}/about`, changeFrequency: 'monthly', priority: 0.4 },
    { url: `${SITE_URL}/contact`, changeFrequency: 'monthly', priority: 0.4 },
    { url: `${SITE_URL}/terms`, changeFrequency: 'yearly', priority: 0.2 },
  ];

  let tyreRoutes: MetadataRoute.Sitemap = [];
  let blogRoutes: MetadataRoute.Sitemap = [];

  try {
    const { data: tyres } = await supabase.from('tyres').select('slug, updated_at');
    tyreRoutes = (tyres || []).map((t) => ({
      url: `${SITE_URL}/tyres/${t.slug}`,
      lastModified: t.updated_at,
      changeFrequency: 'weekly',
      priority: 0.8,
    }));

    const { data: posts } = await supabase.from('blog_posts').select('slug, updated_at').eq('is_published', true);
    blogRoutes = (posts || []).map((p) => ({
      url: `${SITE_URL}/blog/${p.slug}`,
      lastModified: p.updated_at,
      changeFrequency: 'weekly',
      priority: 0.6,
    }));
  } catch {
    // during build without env vars configured yet, skip dynamic routes
  }

  return [...staticRoutes, ...tyreRoutes, ...blogRoutes];
}
