import type { Metadata } from 'next';
import ContactForm from '@/components/ContactForm';

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with Tyrestore.pk for tyre recommendations, order support, or general queries. Reach us via phone, email or WhatsApp.',
};

export default function ContactPage() {
  return (
    <div className="container-xl py-16">
      <h1 className="text-3xl sm:text-4xl font-bold mb-2">Contact Us</h1>
      <p className="text-tyre-black/60 mb-12 normal-case">
        Have a question about a tyre size, your order, or anything else? We're happy to help.
      </p>

      <div className="grid lg:grid-cols-2 gap-12">
        <ContactForm />

        <div className="space-y-8">
          <div>
            <h3 className="font-display text-lg mb-2 text-tyre-red">Phone</h3>
            <p className="normal-case">+92 300 1234567</p>
          </div>
          <div>
            <h3 className="font-display text-lg mb-2 text-tyre-red">Email</h3>
            <p className="normal-case">info@tyrestore.pk</p>
          </div>
          <div>
            <h3 className="font-display text-lg mb-2 text-tyre-red">Address</h3>
            <p className="normal-case">Multan, Punjab, Pakistan</p>
          </div>
          <div>
            <h3 className="font-display text-lg mb-2 text-tyre-red">Business Hours</h3>
            <p className="normal-case">Monday – Saturday: 10:00 AM – 8:00 PM</p>
          </div>
        </div>
      </div>
    </div>
  );
}
