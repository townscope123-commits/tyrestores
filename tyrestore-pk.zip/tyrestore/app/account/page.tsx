import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export default async function AccountPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: orders } = await supabase
    .from('orders')
    .select('*, order_items(*)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <div className="container-xl py-12">
      <h1 className="text-3xl font-bold mb-2">My Account</h1>
      <p className="text-tyre-black/60 mb-10 normal-case">{user.email}</p>

      <h2 className="font-display text-xl mb-4">Order History</h2>
      <div className="space-y-4">
        {(orders || []).map((o: any) => (
          <div key={o.id} className="border border-tyre-line p-5">
            <div className="flex flex-wrap justify-between gap-2 mb-3">
              <span className="font-display">Order #{o.id.slice(0, 8).toUpperCase()}</span>
              <span className="text-xs uppercase font-display px-3 py-1 bg-tyre-fog">{o.status}</span>
            </div>
            <p className="text-sm text-tyre-black/60 normal-case mb-2">
              {new Date(o.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'long', year: 'numeric' })} · {o.payment_method.toUpperCase()}
            </p>
            <ul className="text-sm normal-case space-y-1">
              {o.order_items?.map((item: any) => (
                <li key={item.id}>{item.tyre_title} × {item.quantity} — Rs. {(item.price * item.quantity).toLocaleString()}</li>
              ))}
            </ul>
            <p className="font-display mt-3">Total: Rs. {o.total.toLocaleString()}</p>
          </div>
        ))}
        {(!orders || orders.length === 0) && <p className="text-tyre-black/50 normal-case">No orders yet.</p>}
      </div>
    </div>
  );
}
