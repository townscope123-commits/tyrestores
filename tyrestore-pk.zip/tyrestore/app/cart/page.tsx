'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useCart } from '@/components/CartProvider';

export default function CartPage() {
  const { items, removeItem, updateQty, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="container-xl py-20 text-center">
        <h1 className="text-3xl font-bold mb-4">Your Cart Is Empty</h1>
        <p className="text-tyre-black/60 mb-8 normal-case">Add some tyres to get started.</p>
        <Link href="/tyres" className="btn-primary">Shop Tyres</Link>
      </div>
    );
  }

  return (
    <div className="container-xl py-12">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>
      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div key={item.tyreId} className="flex items-center gap-4 border border-tyre-line p-4">
              <div className="relative w-20 h-20 bg-tyre-fog shrink-0">
                {item.image_url && <Image src={item.image_url} alt={item.title} fill className="object-contain p-2" />}
              </div>
              <div className="flex-1">
                <h3 className="font-display text-sm">{item.title}</h3>
                <p className="text-tyre-red font-display mt-1">Rs. {item.price.toLocaleString()}</p>
              </div>
              <div className="flex items-center border border-tyre-line">
                <button onClick={() => updateQty(item.tyreId, item.quantity - 1)} className="w-8 h-8">−</button>
                <span className="w-8 text-center">{item.quantity}</span>
                <button onClick={() => updateQty(item.tyreId, item.quantity + 1)} className="w-8 h-8">+</button>
              </div>
              <button onClick={() => removeItem(item.tyreId)} className="text-xs text-tyre-red uppercase font-display ml-2">
                Remove
              </button>
            </div>
          ))}
        </div>

        <div className="border border-tyre-line p-6 h-fit">
          <h2 className="font-display text-lg mb-4">Order Summary</h2>
          <div className="flex justify-between text-sm mb-2">
            <span>Subtotal</span>
            <span>Rs. {total.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm mb-4 text-tyre-black/60">
            <span>Shipping</span>
            <span>Calculated at checkout</span>
          </div>
          <div className="flex justify-between font-display text-lg border-t border-tyre-line pt-4 mb-6">
            <span>Total</span>
            <span>Rs. {total.toLocaleString()}</span>
          </div>
          <Link href="/checkout" className="btn-primary w-full">Proceed To Checkout</Link>
        </div>
      </div>
    </div>
  );
}
