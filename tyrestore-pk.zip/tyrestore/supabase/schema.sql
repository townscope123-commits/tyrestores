-- =========================================================
-- TYRESTORE.PK — SUPABASE DATABASE SCHEMA
-- Supabase Dashboard -> SQL Editor -> paste this whole file -> Run
-- =========================================================

-- 1. PROFILES (extends Supabase auth.users). is_admin flags admin panel access.
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  is_admin boolean default false,
  created_at timestamptz default now()
);

-- Auto-create a profile row whenever someone signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2. LOGIN SESSIONS LOG (so admin can see "kon login kar raha hai")
create table if not exists login_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  email text,
  logged_in_at timestamptz default now(),
  user_agent text
);

-- 3. TYRE CATEGORIES / BRANDS
create table if not exists brands (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique
);

-- 4. TYRES (products)
create table if not exists tyres (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  brand_id uuid references brands(id),
  size text,                 -- e.g. 185/65 R15
  pattern text,               -- tread pattern name
  season text default 'All Season', -- Summer / Winter / All Season
  price numeric not null default 0,
  discount_price numeric,
  stock integer default 0,
  short_description text,
  description_html text,      -- rich text editor content (HTML)
  image_url text,
  gallery_urls text[],
  is_featured boolean default false,
  meta_title text,
  meta_description text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists idx_tyres_slug on tyres(slug);

-- 5. BLOG POSTS
create table if not exists blog_posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  cover_image_url text,
  excerpt text,
  content_html text,
  author_id uuid references auth.users(id),
  is_published boolean default true,
  meta_title text,
  meta_description text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 6. PAYMENT METHODS (admin configurable: COD, Bank Transfer, etc.)
create table if not exists payment_methods (
  id uuid primary key default gen_random_uuid(),
  method_key text not null unique,  -- 'cod' | 'bank_transfer'
  label text not null,
  instructions text,                 -- e.g. bank account details shown at checkout
  is_enabled boolean default true
);

insert into payment_methods (method_key, label, instructions, is_enabled)
values
  ('cod', 'Cash on Delivery', 'Pay in cash when your order is delivered.', true),
  ('bank_transfer', 'Bank Transfer', 'Transfer to our bank account and share the receipt on WhatsApp.', true)
on conflict (method_key) do nothing;

-- 7. ORDERS
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  customer_name text not null,
  phone text not null,
  address text not null,
  city text not null,
  payment_method text not null default 'cod',
  status text not null default 'pending', -- pending / confirmed / shipped / delivered / cancelled
  total numeric not null default 0,
  created_at timestamptz default now()
);

create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  tyre_id uuid references tyres(id),
  tyre_title text not null,
  quantity integer not null default 1,
  price numeric not null
);

-- =========================================================
-- ROW LEVEL SECURITY
-- =========================================================
alter table profiles enable row level security;
alter table tyres enable row level security;
alter table blog_posts enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table payment_methods enable row level security;
alter table login_logs enable row level security;
alter table brands enable row level security;

-- Public can read tyres, blog, brands, enabled payment methods
create policy "public read tyres" on tyres for select using (true);
create policy "public read brands" on brands for select using (true);
create policy "public read published blog" on blog_posts for select using (is_published = true);
create policy "public read payment methods" on payment_methods for select using (true);

-- Only admins can write tyres/blog/brands/payment_methods
create policy "admin write tyres" on tyres for all using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
) with check (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

create policy "admin write blog" on blog_posts for all using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
) with check (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

create policy "admin write brands" on brands for all using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
) with check (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

create policy "admin write payment methods" on payment_methods for all using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
) with check (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

-- Orders: customers can create + view their own; admins can view/update all
create policy "customers create orders" on orders for insert with check (true);
create policy "customers view own orders" on orders for select using (
  auth.uid() = user_id or exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);
create policy "admin update orders" on orders for update using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);

create policy "create order items" on order_items for insert with check (true);
create policy "view order items" on order_items for select using (
  exists (
    select 1 from orders o where o.id = order_id
    and (o.user_id = auth.uid() or exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true))
  )
);

-- Profiles: users see/edit their own row; admins see all
create policy "users view own profile" on profiles for select using (
  auth.uid() = id or exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true)
);
create policy "users update own profile" on profiles for update using (auth.uid() = id);

-- Login logs: only admins can read; anyone (server) can insert their own
create policy "admin read login logs" on login_logs for select using (
  exists (select 1 from profiles where id = auth.uid() and is_admin = true)
);
create policy "insert own login log" on login_logs for insert with check (auth.uid() = user_id);

-- =========================================================
-- MAKE YOURSELF ADMIN
-- 1. Sign up normally on the site (or Supabase Auth -> Add User)
-- 2. Then run this (replace the email):
--    update profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');
-- =========================================================

-- =========================================================
-- STORAGE BUCKET FOR TYRE & BLOG IMAGES
-- Run this after the tables above. Then also do this manually:
-- Supabase Dashboard -> Storage -> confirm bucket "tyre-images" exists and is Public.
-- =========================================================
insert into storage.buckets (id, name, public)
values ('tyre-images', 'tyre-images', true)
on conflict (id) do nothing;

create policy "public read tyre images" on storage.objects
  for select using (bucket_id = 'tyre-images');

create policy "admin upload tyre images" on storage.objects
  for insert with check (
    bucket_id = 'tyre-images'
    and exists (select 1 from profiles where id = auth.uid() and is_admin = true)
  );

create policy "admin delete tyre images" on storage.objects
  for delete using (
    bucket_id = 'tyre-images'
    and exists (select 1 from profiles where id = auth.uid() and is_admin = true)
  );
