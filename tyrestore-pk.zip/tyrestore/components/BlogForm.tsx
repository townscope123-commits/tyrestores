'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import slugify from 'slugify';
import { createClient } from '@/lib/supabase/client';
import RichTextEditor from './RichTextEditor';

export type BlogFormData = {
  id?: string;
  title: string;
  excerpt: string;
  content_html: string;
  cover_image_url: string;
  is_published: boolean;
  meta_title: string;
  meta_description: string;
};

const EMPTY: BlogFormData = {
  title: '', excerpt: '', content_html: '', cover_image_url: '', is_published: true, meta_title: '', meta_description: '',
};

export default function BlogForm({ initial }: { initial?: BlogFormData }) {
  const supabase = createClient();
  const router = useRouter();
  const [form, setForm] = useState<BlogFormData>(initial || EMPTY);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleImageUpload = async (file: File) => {
    setUploading(true);
    const path = `blog/${Date.now()}-${file.name}`;
    const { error: uploadErr } = await supabase.storage.from('tyre-images').upload(path, file);
    if (uploadErr) {
      setError('Image upload failed: ' + uploadErr.message);
      setUploading(false);
      return;
    }
    const { data } = supabase.storage.from('tyre-images').getPublicUrl(path);
    setForm((f) => ({ ...f, cover_image_url: data.publicUrl }));
    setUploading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    const { data: userData } = await supabase.auth.getUser();
    const slug = slugify(form.title, { lower: true, strict: true });
    const payload = { ...form, slug, author_id: userData.user?.id, updated_at: new Date().toISOString() };

    const query = form.id
      ? supabase.from('blog_posts').update(payload).eq('id', form.id)
      : supabase.from('blog_posts').insert(payload);

    const { error: saveErr } = await query;
    if (saveErr) {
      setError(saveErr.message);
      setSaving(false);
      return;
    }

    router.push('/admin/blog');
    router.refresh();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl">
      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Post Title</label>
        <input
          required
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>

      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Excerpt</label>
        <textarea
          value={form.excerpt}
          onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
          rows={2}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>

      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Cover Image</label>
        <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])} />
        {uploading && <p className="text-xs text-tyre-black/50 mt-1">Uploading...</p>}
        {form.cover_image_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={form.cover_image_url} alt="preview" className="w-32 h-20 object-cover mt-2 border border-tyre-line" />
        )}
      </div>

      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-2">Content (Rich Text Editor)</label>
        <RichTextEditor
          value={form.content_html}
          onChange={(html) => setForm({ ...form, content_html: html })}
          placeholder="Write the blog post content..."
        />
      </div>

      <div className="flex items-center gap-2">
        <input
          id="published"
          type="checkbox"
          checked={form.is_published}
          onChange={(e) => setForm({ ...form, is_published: e.target.checked })}
        />
        <label htmlFor="published" className="text-sm font-display uppercase tracking-wide">Published</label>
      </div>

      <div className="grid sm:grid-cols-2 gap-5 pt-4 border-t border-tyre-line">
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">SEO Meta Title</label>
          <input
            value={form.meta_title}
            onChange={(e) => setForm({ ...form, meta_title: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">SEO Meta Description</label>
          <input
            value={form.meta_description}
            onChange={(e) => setForm({ ...form, meta_description: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
      </div>

      {error && <p className="text-tyre-red text-sm">{error}</p>}

      <button disabled={saving || uploading} type="submit" className="btn-primary">
        {saving ? 'Saving...' : form.id ? 'Update Post' : 'Publish Post'}
      </button>
    </form>
  );
}
