export default function WhatsAppButton() {
  const number = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '923001234567';
  const message = encodeURIComponent('Assalam-o-Alaikum, mujhe tyre ke baray mein maloomat chahiye.');

  return (
    <a
      href={`https://wa.me/${number}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] shadow-lg hover:scale-110 transition-transform animate-bounce-slow"
    >
      <svg viewBox="0 0 32 32" className="w-8 h-8 fill-white">
        <path d="M16.001 3C9.373 3 4 8.373 4 15c0 2.396.702 4.63 1.912 6.507L4 29l7.676-1.885A11.94 11.94 0 0 0 16.001 27C22.63 27 28 21.627 28 15S22.63 3 16.001 3zm0 21.818a9.78 9.78 0 0 1-4.99-1.363l-.358-.213-4.554 1.119 1.216-4.437-.234-.456A9.78 9.78 0 0 1 6.182 15c0-5.415 4.404-9.818 9.819-9.818S25.82 9.585 25.82 15 21.416 24.818 16.001 24.818zm5.373-7.347c-.294-.147-1.74-.859-2.009-.957-.27-.098-.467-.147-.663.147-.196.294-.76.957-.932 1.153-.171.196-.343.221-.637.074-.294-.147-1.242-.458-2.366-1.463-.874-.78-1.464-1.744-1.636-2.038-.171-.294-.018-.453.129-.6.132-.132.294-.343.441-.514.147-.171.196-.294.294-.49.098-.196.049-.368-.025-.514-.074-.147-.663-1.6-.909-2.19-.24-.575-.484-.497-.663-.506-.171-.008-.368-.01-.564-.01-.196 0-.514.074-.783.368-.27.294-1.03 1.006-1.03 2.454s1.054 2.847 1.201 3.043c.147.196 2.075 3.168 5.028 4.44.703.303 1.251.484 1.678.62.705.224 1.347.192 1.854.117.566-.084 1.74-.712 1.985-1.4.245-.688.245-1.278.171-1.4-.073-.123-.269-.196-.563-.343z"/>
      </svg>
    </a>
  );
}
