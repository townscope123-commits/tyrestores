import Link from 'next/link';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-tyre-black text-white mt-20">
      <div className="tread-divider" />
      <div className="container-xl py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <span className="font-display text-2xl font-bold">
            TYRE<span className="text-tyre-red">STORE</span>.PK
          </span>
          <p className="mt-4 text-sm text-white/60 leading-relaxed">
            Pakistan's trusted online tyre store — genuine, imported and locally manufactured tyres
            for cars, SUVs and bikes, delivered to your doorstep with Cash on Delivery.
          </p>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-wide mb-4 text-tyre-red">Quick Links</h4>
          <ul className="space-y-2 text-sm text-white/70">
            <li><Link href="/tyres" className="hover:text-white">Shop Tyres</Link></li>
            <li><Link href="/blog" className="hover:text-white">Blog</Link></li>
            <li><Link href="/about" className="hover:text-white">About Us</Link></li>
            <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
            <li><Link href="/terms" className="hover:text-white">Terms &amp; Conditions</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-wide mb-4 text-tyre-red">Shop By</h4>
          <ul className="space-y-2 text-sm text-white/70">
            <li><Link href="/tyres?season=Summer" className="hover:text-white">Summer Tyres</Link></li>
            <li><Link href="/tyres?season=Winter" className="hover:text-white">Winter Tyres</Link></li>
            <li><Link href="/tyres?season=All+Season" className="hover:text-white">All Season Tyres</Link></li>
            <li><Link href="/tyres?featured=1" className="hover:text-white">Featured Tyres</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-sm tracking-wide mb-4 text-tyre-red">Contact Us</h4>
          <ul className="space-y-2 text-sm text-white/70">
            <li>Multan, Punjab, Pakistan</li>
            <li><a href="tel:+923001234567" className="hover:text-white">+92 300 1234567</a></li>
            <li><a href="mailto:info@tyrestore.pk" className="hover:text-white">info@tyrestore.pk</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-4">
        <div className="container-xl flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-white/50">
          <span>© {year} Tyrestore.pk — All rights reserved.</span>
          <span>Designed &amp; built for Pakistan's roads.</span>
        </div>
      </div>
    </footer>
  );
}
