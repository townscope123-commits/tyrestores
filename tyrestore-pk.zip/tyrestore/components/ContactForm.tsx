'use client';

import { useState } from 'react';

export default function ContactForm() {
  const [form, setForm] = useState({ name: '', phone: '', message: '' });
  const number = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '923001234567';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = encodeURIComponent(
      `Name: ${form.name}\nPhone: ${form.phone}\nMessage: ${form.message}`
    );
    window.open(`https://wa.me/${number}?text=${text}`, '_blank');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Your Name</label>
        <input
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>
      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Phone Number</label>
        <input
          required
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>
      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Message</label>
        <textarea
          required
          rows={5}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>
      <button type="submit" className="btn-primary">Send via WhatsApp</button>
    </form>
  );
}
