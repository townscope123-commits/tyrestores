'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from './CartProvider';

export default function AddToCartButton({
  tyreId,
  title,
  price,
  image_url,
}: {
  tyreId: string;
  title: string;
  price: number;
  image_url: string | null;
}) {
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const router = useRouter();

  const handleAdd = () => {
    addItem({ tyreId, title, price, image_url }, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
      <div className="flex items-center border border-tyre-line w-fit">
        <button
          onClick={() => setQty((q) => Math.max(1, q - 1))}
          className="w-10 h-10 flex items-center justify-center hover:bg-tyre-fog font-display text-lg"
          aria-label="Decrease quantity"
        >
          −
        </button>
        <span className="w-10 text-center font-display">{qty}</span>
        <button
          onClick={() => setQty((q) => q + 1)}
          className="w-10 h-10 flex items-center justify-center hover:bg-tyre-fog font-display text-lg"
          aria-label="Increase quantity"
        >
          +
        </button>
      </div>
      <button onClick={handleAdd} className="btn-primary">
        {added ? 'Added ✓' : 'Add To Cart'}
      </button>
      <button
        onClick={() => {
          addItem({ tyreId, title, price, image_url }, qty);
          router.push('/checkout');
        }}
        className="btn-outline"
      >
        Buy Now
      </button>
    </div>
  );
}
