'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

const LINKS = [
  { href: '/admin', label: 'Dashboard' },
  { href: '/admin/tyres', label: 'Tyres' },
  { href: '/admin/blog', label: 'Blog Posts' },
  { href: '/admin/orders', label: 'Orders' },
  { href: '/admin/users', label: 'Logged-In Users' },
  { href: '/admin/settings', label: 'Payment Settings' },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/admin/login');
    router.refresh();
  };

  return (
    <aside className="w-full sm:w-64 shrink-0 bg-tyre-black text-white sm:min-h-screen">
      <div className="p-6 border-b border-white/10">
        <span className="font-display text-xl font-bold">
          TYRE<span className="text-tyre-red">STORE</span>
        </span>
        <p className="text-[10px] uppercase tracking-widest text-white/40 mt-1">Admin Panel</p>
      </div>
      <nav className="p-4 space-y-1">
        {LINKS.map((link) => {
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`block px-4 py-2.5 text-sm font-display uppercase tracking-wide rounded-sm ${
                active ? 'bg-tyre-red text-white' : 'text-white/70 hover:bg-white/10'
              }`}
            >
              {link.label}
            </Link>
          );
        })}
        <button
          onClick={handleLogout}
          className="w-full text-left px-4 py-2.5 text-sm font-display uppercase tracking-wide text-white/50 hover:bg-white/10 mt-4"
        >
          Logout
        </button>
      </nav>
    </aside>
  );
}
