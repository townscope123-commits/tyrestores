'use client';

import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function DeleteButton({ table, id }: { table: string; id: string }) {
  const supabase = createClient();
  const router = useRouter();

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this item?')) return;
    await supabase.from(table).delete().eq('id', id);
    router.refresh();
  };

  return (
    <button onClick={handleDelete} className="text-tyre-black/50 hover:text-tyre-red font-display text-xs uppercase">
      Delete
    </button>
  );
}
