import Link from 'next/link';
import Image from 'next/image';

export type Tyre = {
  id: string;
  title: string;
  slug: string;
  size: string | null;
  season: string | null;
  price: number;
  discount_price: number | null;
  image_url: string | null;
  is_featured?: boolean | null;
};

export default function TyreCard({ tyre }: { tyre: Tyre }) {
  const hasDiscount = tyre.discount_price && tyre.discount_price < tyre.price;

  return (
    <Link
      href={`/tyres/${tyre.slug}`}
      className="group block border border-tyre-line rounded-sm overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all bg-white"
    >
      <div className="relative aspect-square bg-tyre-fog overflow-hidden">
        {tyre.image_url ? (
          <Image
            src={tyre.image_url}
            alt={tyre.title}
            fill
            className="object-contain p-6 group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-tyre-black/20 font-display text-4xl">TS</div>
        )}
        {tyre.is_featured && (
          <span className="absolute top-2 left-2 bg-tyre-red text-white text-[10px] font-display uppercase tracking-wide px-2 py-1">
            Featured
          </span>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs uppercase tracking-wide text-tyre-black/50">{tyre.season || 'All Season'} · {tyre.size}</p>
        <h3 className="font-display text-base font-medium mt-1 group-hover:text-tyre-red transition-colors line-clamp-2">
          {tyre.title}
        </h3>
        <div className="mt-2 flex items-center gap-2">
          {hasDiscount ? (
            <>
              <span className="font-display text-lg text-tyre-red">Rs. {tyre.discount_price!.toLocaleString()}</span>
              <span className="text-sm text-tyre-black/40 line-through">Rs. {tyre.price.toLocaleString()}</span>
            </>
          ) : (
            <span className="font-display text-lg text-tyre-black">Rs. {tyre.price.toLocaleString()}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
