'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import slugify from 'slugify';
import { createClient } from '@/lib/supabase/client';
import RichTextEditor from './RichTextEditor';

export type TyreFormData = {
  id?: string;
  title: string;
  size: string;
  pattern: string;
  season: string;
  price: number;
  discount_price: number | null;
  stock: number;
  short_description: string;
  description_html: string;
  image_url: string;
  is_featured: boolean;
  meta_title: string;
  meta_description: string;
};

const EMPTY: TyreFormData = {
  title: '', size: '', pattern: '', season: 'All Season', price: 0, discount_price: null,
  stock: 0, short_description: '', description_html: '', image_url: '', is_featured: false,
  meta_title: '', meta_description: '',
};

export default function TyreForm({ initial }: { initial?: TyreFormData }) {
  const supabase = createClient();
  const router = useRouter();
  const [form, setForm] = useState<TyreFormData>(initial || EMPTY);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleImageUpload = async (file: File) => {
    setUploading(true);
    const path = `tyres/${Date.now()}-${file.name}`;
    const { error: uploadErr } = await supabase.storage.from('tyre-images').upload(path, file);
    if (uploadErr) {
      setError('Image upload failed: ' + uploadErr.message);
      setUploading(false);
      return;
    }
    const { data } = supabase.storage.from('tyre-images').getPublicUrl(path);
    setForm((f) => ({ ...f, image_url: data.publicUrl }));
    setUploading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    const slug = slugify(form.title, { lower: true, strict: true });
    const payload = { ...form, slug, updated_at: new Date().toISOString() };

    const query = form.id
      ? supabase.from('tyres').update(payload).eq('id', form.id)
      : supabase.from('tyres').insert(payload);

    const { error: saveErr } = await query;
    if (saveErr) {
      setError(saveErr.message);
      setSaving(false);
      return;
    }

    router.push('/admin/tyres');
    router.refresh();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl">
      <div className="grid sm:grid-cols-2 gap-5">
        <div className="sm:col-span-2">
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Tyre Title</label>
          <input
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
            placeholder="e.g. General Tire Altimax 185/65 R15"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Size</label>
          <input
            value={form.size}
            onChange={(e) => setForm({ ...form, size: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
            placeholder="185/65 R15"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Pattern</label>
          <input
            value={form.pattern}
            onChange={(e) => setForm({ ...form, pattern: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Season</label>
          <select
            value={form.season}
            onChange={(e) => setForm({ ...form, season: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          >
            <option>Summer</option>
            <option>Winter</option>
            <option>All Season</option>
          </select>
        </div>
        <div className="flex items-end gap-2 pb-3">
          <input
            id="featured"
            type="checkbox"
            checked={form.is_featured}
            onChange={(e) => setForm({ ...form, is_featured: e.target.checked })}
          />
          <label htmlFor="featured" className="text-sm font-display uppercase tracking-wide">Featured Tyre</label>
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Price (Rs.)</label>
          <input
            type="number"
            required
            value={form.price}
            onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Discount Price (optional)</label>
          <input
            type="number"
            value={form.discount_price ?? ''}
            onChange={(e) => setForm({ ...form, discount_price: e.target.value ? Number(e.target.value) : null })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Stock Quantity</label>
          <input
            type="number"
            required
            value={form.stock}
            onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">Tyre Image</label>
          <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])} />
          {uploading && <p className="text-xs text-tyre-black/50 mt-1">Uploading...</p>}
          {form.image_url && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={form.image_url} alt="preview" className="w-20 h-20 object-contain mt-2 border border-tyre-line" />
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-1">Short Description</label>
        <textarea
          value={form.short_description}
          onChange={(e) => setForm({ ...form, short_description: e.target.value })}
          rows={2}
          className="w-full border border-tyre-line px-4 py-3"
        />
      </div>

      <div>
        <label className="block text-sm font-display uppercase tracking-wide mb-2">
          Full Description (Rich Text Editor)
        </label>
        <RichTextEditor
          value={form.description_html}
          onChange={(html) => setForm({ ...form, description_html: html })}
          placeholder="Write detailed information about this tyre — features, benefits, fitment notes..."
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-5 pt-4 border-t border-tyre-line">
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">SEO Meta Title</label>
          <input
            value={form.meta_title}
            onChange={(e) => setForm({ ...form, meta_title: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
        <div>
          <label className="block text-sm font-display uppercase tracking-wide mb-1">SEO Meta Description</label>
          <input
            value={form.meta_description}
            onChange={(e) => setForm({ ...form, meta_description: e.target.value })}
            className="w-full border border-tyre-line px-4 py-3"
          />
        </div>
      </div>

      {error && <p className="text-tyre-red text-sm">{error}</p>}

      <button disabled={saving || uploading} type="submit" className="btn-primary">
        {saving ? 'Saving...' : form.id ? 'Update Tyre' : 'Publish Tyre'}
      </button>
    </form>
  );
}
