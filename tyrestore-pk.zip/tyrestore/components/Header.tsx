import Link from 'next/link';

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/tyres', label: 'Shop Tyres' },
  { href: '/blog', label: 'Blog' },
  { href: '/about', label: 'About Us' },
  { href: '/contact', label: 'Contact' },
];

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white">
      {/* Top announcement strip — required: shipping/advance line above header */}
      <div className="bg-tyre-black text-white text-xs sm:text-sm">
        <div className="container-xl flex items-center justify-center py-2 text-center">
          <span className="font-medium tracking-wide">
            🚚 Free Advance Shipping Across Pakistan on Orders Above Rs. 30,000 &nbsp;|&nbsp; Cash on Delivery Available
          </span>
        </div>
      </div>

      {/* Main header */}
      <div className="border-b border-tyre-line">
        <div className="container-xl flex items-center justify-between py-4 gap-6">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="font-display text-2xl sm:text-3xl font-bold text-tyre-black">
              TYRE<span className="text-tyre-red">STORE</span>
            </span>
            <span className="font-display text-xs text-tyre-black/60 self-end pb-1 hidden sm:inline">.PK</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="font-display uppercase text-sm tracking-wide text-tyre-black hover:text-tyre-red transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <Link href="/cart" className="font-display text-sm uppercase tracking-wide hover:text-tyre-red transition-colors">
              Cart
            </Link>
            <Link href="/login" className="btn-outline !px-4 !py-2 text-xs">
              Login
            </Link>
          </div>
        </div>
        {/* mobile nav */}
        <div className="md:hidden flex overflow-x-auto gap-6 px-4 pb-3 -mt-1">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="font-display uppercase text-xs tracking-wide whitespace-nowrap text-tyre-black hover:text-tyre-red"
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="tread-divider" />
    </header>
  );
}
